package com.example.employee_directory;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeDirectoryApplicationTests {

	@Test
	void contextLoads() {
	}

}
