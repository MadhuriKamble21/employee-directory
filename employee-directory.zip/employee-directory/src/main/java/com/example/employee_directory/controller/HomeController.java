package com.example.employee_directory.controller;

import com.example.employee_directory.model.Employee;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

@Controller
public class HomeController {

    // In-memory list of employees
    private final List<Employee> employeeList = new ArrayList<>();
    private final AtomicInteger idCounter = new AtomicInteger(1); // For auto-increment ID

    // Constructor with sample data
    public HomeController() {
        employeeList.add(new Employee(idCounter.getAndIncrement(), "Alice", "Smith", "alice@example.com", "Engineering", "Developer"));
        employeeList.add(new Employee(idCounter.getAndIncrement(), "Bob", "Johnson", "bob@example.com", "HR", "Manager"));
    }

    // Show dashboard
    @GetMapping("/dashboard")
    public String showDashboard(Model model) {
        model.addAttribute("employees", employeeList);
        return "dashboard";
    }

    // Show add form
    @GetMapping("/add")
    public String addEmployeeForm() {
        return "form";
    }

    // Handle form POST
    @PostMapping("/add")
    public String submitEmployee(
            @RequestParam String firstName,
            @RequestParam String lastName,
            @RequestParam String email,
            @RequestParam String department,
            @RequestParam String role
    ) {
        int newId = idCounter.getAndIncrement();
        employeeList.add(new Employee(newId, firstName, lastName, email, department, role));
        return "redirect:/dashboard";
    }
}
